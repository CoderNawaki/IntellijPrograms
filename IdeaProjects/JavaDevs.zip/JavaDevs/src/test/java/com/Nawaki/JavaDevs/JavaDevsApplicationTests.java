package com.Nawaki.JavaDevs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaDevsApplicationTests {

	@Test
	void contextLoads() {
	}

}
